

public class Main {

    public static void main(String[] args) {

        Cola cola = new Cola();

        System.out.println(cola.estaVacia());

        for (int i = 1; i <= 5; i++) {

            cola.insertar(i);

        }

        //encolado los elementos

        System.out.println("MOSTRANDO ELEMENTOS DE LA COLA: "); cola.mostrar();

        System.out.println("ELIMINANDO ELEMENTOS DE LA COLA:");
        
        cola.eliminar();

        cola.eliminar();

        cola.mostrar();


            
        }



        //insertar elementos  a la cola

        /*
        Cola.insertar(5);
        Cola.insertar(4);
        Cola.insertar(3);
        Cola.insertar(2);
        Cola.insertar(1);
        Cola.insertar(0);


        //mostrar la colita


        cola.mostrar();


        //eliminar algunos elementos

        cola.eliminar();
        cola.eliminar();

        //y mostramos nuevamente la colita

        cola.mostrar();


    }
*/

}
