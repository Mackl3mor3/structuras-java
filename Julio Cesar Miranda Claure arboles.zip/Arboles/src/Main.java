import ARBOLESBI.ArbolBinarioBusqueda;

public class Main {

    public static void main(String[] args) {

        ArbolBinarioBusqueda Arbolito = new ArbolBinarioBusqueda();

        System.out.println("MOSTRANDO LOS ELEMENTOS EN ORDEN");

        Arbolito.insertar(0);
        Arbolito.insertar(2);
        Arbolito.insertar(4);
        Arbolito.insertar(1);
        Arbolito.insertar(3);
        Arbolito.insertar(5);
        Arbolito.insertar(7);
        Arbolito.insertar(6);



        Arbolito.mostrarPreOrden();

        System.out.println("MOSTRANDO LOS ELEMENTOS EN ORDEN pre");

        Arbolito.insertar(43);
        Arbolito.insertar(24);
        Arbolito.insertar(62);
        Arbolito.insertar(122);
        Arbolito.insertar(342);
        Arbolito.insertar(52);
        Arbolito.insertar(724);
        Arbolito.insertar(20);

        Arbolito.mostrarInOrden();

        System.out.println("MOSTRANDO LOS ELEMENTOS EN ORDEN post ");

        Arbolito.insertar(41);
        Arbolito.insertar(234);
        Arbolito.insertar(642);
        Arbolito.insertar(1522);
        Arbolito.insertar(3452);
        Arbolito.insertar(542);
        Arbolito.insertar(7324);
        Arbolito.insertar(202);

        Arbolito.mostrarPostOrden();




    }
}
