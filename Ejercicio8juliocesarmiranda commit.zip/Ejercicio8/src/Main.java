import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String[] Nombre = new String[5];

        double[] Edad = new double[5];

        String nombreAlumno;

        double edadAlumno;

        int i=0;

        do {

            i++;

            System.out.print("Digite el nombre del alumno: " + (i+1) + ": ");

            Nombre[i] = sc.nextLine();

            if(!Nombre[i].equals("*")){

                System.out.print("Digite la edad del alumno: ");

                Edad[i] = sc.nextDouble();
            }
            else
                {
                break;
               }

        }
        while (Nombre[i].equals("*"));

        edadAlumno = Edad[i];

        nombreAlumno = Nombre[i];



        //se ingresa el * para interrumpir el escaneo del programa y pasar al resultado

        for (i = 1; i < Nombre.length; i++ ) {

            sc.nextLine();

            System.out.print("Digite el nombre del alumno " + (i + 1) + ": ");

            Nombre[i] = sc.nextLine();

            System.out.print("Digite la edad del alumno: ");

            Edad[i] = sc.nextDouble();


            //se compara el con la edad mayor del alumno

            if (Edad[i] > edadAlumno ) {

                edadAlumno = Edad[i];

                nombreAlumno = Nombre[i];

            }



        }

        //muestra resultados



        System.out.println("Alumno con mayor edad: " + nombreAlumno );

        System.out.println("Edad: " + edadAlumno);



    }
}