//Queremos guardar los nombres y la edades de los alumnos de un curso.
//Realiza un programa que introduzca el nombre y la edad de cada alumno.
//El proceso de lectura de datos terminará cuando se introduzca como nombre
//un asterisco (*) Al finalizar se mostrará los siguientes datos:
// * Los alumnos mayores (los que tienen más edad)

import java.util.*;

public class Alumnos {



    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        String[] Nombre = new String[0];

        double[] Edad = new double[0];


        //variables donde guardar el nombre y la edad del alumno con mayor edad
        String nombreAlumno;

        double edadAlumno;

        int i = 0;

        //se ingresa el * para interrumpir el escaneo del programa y pasar al resultado


        System.out.println("INGRESE * SI DESEA DETENER EL SCANEO Y PASAR AL REGISTRO DE ALUMNOS PARA DETERMINAR QUIEN ES MAYOR: ");
        String input = sc.nextLine();

        if (input.equals("*"));



        System.out.print("Digite el nombre del alumno: " + (i + 1 ) + ": ");

        Nombre[i] = sc.nextLine();

        System.out.print("Digite la edad del alumno: ");

        Edad[i] = sc.nextDouble();

        edadAlumno = Edad[i];

        nombreAlumno = Nombre[i];



        for (i = 1; i < Nombre.length; i++) {

            sc.nextLine();

            System.out.print("Digite el nombre del alumno " + (i + 1) + ": ");

            Nombre[i] = sc.nextLine();

            System.out.print("Digite la edad del alumno: ");

            Edad[i] = sc.nextDouble();

            System.out.println("Digite * para parar el codigo");

            //se compara el con la edad mayor del alumno

            if (Edad[i] > edadAlumno ) {

                edadAlumno = Edad[i];

                nombreAlumno = Nombre[i];

            }


        }

        //mostrar resultados


        System.out.println("Alumno con mayor edad: " + nombreAlumno );

        System.out.println("Edad: " + edadAlumno);



    }



}
